
import React, { useState } from 'react';
import { Screen, Session } from './types';
import Dashboard from './screens/Dashboard';
import Library from './screens/Library';
import Analytics from './screens/Analytics';
import SessionPlayer from './screens/SessionPlayer';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [activeScreen, setActiveScreen] = useState<Screen>(Screen.DASHBOARD);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);

  const startSession = (session: Session) => {
    setCurrentSession(session);
    setActiveScreen(Screen.PLAYER);
  };

  const renderScreen = () => {
    switch (activeScreen) {
      case Screen.DASHBOARD:
        return <Dashboard onNavigate={setActiveScreen} onStartSession={startSession} />;
      case Screen.LIBRARY:
        return <Library onStartSession={startSession} />;
      case Screen.ANALYTICS:
        return <Analytics />;
      case Screen.PLAYER:
        return currentSession ? (
          <SessionPlayer 
            session={currentSession} 
            onClose={() => setActiveScreen(Screen.DASHBOARD)} 
          />
        ) : null;
      case Screen.SETTINGS:
        return (
          <div className="flex flex-col items-center justify-center h-full text-slate-400 p-8 text-center">
            <h2 className="text-2xl font-bold mb-4 font-inter">Settings</h2>
            <p className="max-w-xs">Manage your VR Headset connection, profile data, and subscription here.</p>
          </div>
        );
      default:
        return <Dashboard onNavigate={setActiveScreen} onStartSession={startSession} />;
    }
  };

  // Only show layout if not in immersive player mode
  const showLayout = activeScreen !== Screen.PLAYER;

  if (!showLayout) return renderScreen();

  return (
    <Layout activeScreen={activeScreen} setActiveScreen={setActiveScreen}>
      {renderScreen()}
    </Layout>
  );
};

export default App;
