
import { GoogleGenAI } from "@google/genai";

export const getSmartInsight = async (userData: any) => {
  if (!process.env.API_KEY) {
    return "Complete more sessions to unlock personalized AI insights.";
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a 20-word fitness advice for a Pilates user who has completed ${userData.sessions} sessions this month.`,
    });
    return response.text || "Keep pushing your limits, you're doing great!";
  } catch (err) {
    console.error("Gemini Error:", err);
    return "Great work! Try an advanced core session tomorrow.";
  }
};
