
export enum Screen {
  DASHBOARD = 'DASHBOARD',
  LIBRARY = 'LIBRARY',
  ANALYTICS = 'ANALYTICS',
  SETTINGS = 'SETTINGS',
  PLAYER = 'PLAYER'
}

export interface Session {
  id: string;
  title: string;
  instructor: string;
  duration: number;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  imageUrl: string;
  isPopular?: boolean;
  videoCues?: string[]; // Times for AI feedback
}

export interface UserStats {
  totalMinutes: number;
  dailyStreak: number;
  progressPercent: number;
  weeklyActivity: { day: string; minutes: number }[];
  completionRate: number;
}
