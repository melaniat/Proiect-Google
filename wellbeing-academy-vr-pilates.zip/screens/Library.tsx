
import React, { useState } from 'react';
// Added ChevronRight to imports
import { Search, ChevronDown, Filter, ChevronRight } from 'lucide-react';
import { SessionCard } from '../components/UI';
import { Session } from '../types';

const MOCK_SESSIONS: Session[] = [
  {
    id: 's1',
    title: 'Core Power Flow',
    instructor: 'Sarah Jenkins',
    duration: 20,
    level: 'Intermediate',
    category: 'Core',
    imageUrl: 'https://images.unsplash.com/photo-1522845015757-5810024f0e55?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: 's2',
    title: 'Zen Morning Stretch',
    instructor: 'Marcus Thorne',
    duration: 25,
    level: 'Beginner',
    category: 'Flexibility',
    imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: 's3',
    title: 'Stability Pro Mastery',
    instructor: 'Elena Rodriguez',
    duration: 30,
    level: 'Advanced',
    category: 'Core',
    imageUrl: 'https://images.unsplash.com/photo-1574680077505-ff0961734991?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: 's4',
    title: 'Breath & Balance',
    instructor: 'Sarah Jenkins',
    duration: 15,
    level: 'Beginner',
    category: 'Balance',
    imageUrl: 'https://images.unsplash.com/photo-1510894347713-fc3ed6fdf539?q=80&w=800&auto=format&fit=crop',
  }
];

interface LibraryProps {
  onStartSession: (s: Session) => void;
}

const Library: React.FC<LibraryProps> = ({ onStartSession }) => {
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredSessions = activeFilter === 'All' 
    ? MOCK_SESSIONS 
    : MOCK_SESSIONS.filter(s => s.category === activeFilter);

  return (
    <div className="p-6 space-y-6 pb-24">
      <header className="flex items-center justify-between">
        <div>
           <h1 className="text-2xl font-bold">VR Catalog</h1>
           <p className="text-xs text-slate-500 font-medium">Curated for your level</p>
        </div>
        <button className="p-2 glass rounded-full">
          <Search size={20} className="text-slate-400" />
        </button>
      </header>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 scroll-hide">
        <button className="glass px-4 py-2 rounded-2xl flex items-center gap-2 text-sm font-bold bg-[#00C2FF] text-black border-none whitespace-nowrap">
          <Filter size={14} /> Filters
        </button>
        {['All', 'Core', 'Flexibility', 'Balance'].map(cat => (
          <button 
            key={cat}
            onClick={() => setActiveFilter(cat)}
            className={`px-5 py-2 rounded-2xl text-sm font-bold border transition-all whitespace-nowrap ${
              activeFilter === cat ? 'bg-slate-700 border-slate-600 text-white' : 'glass border-transparent text-slate-500 hover:text-slate-300'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Sessions Grid */}
      <section className="grid grid-cols-1 gap-6">
        {filteredSessions.map(session => (
          <div key={session.id} onClick={() => onStartSession(session)}>
            <SessionCard session={session} orientation="horizontal" />
          </div>
        ))}
      </section>

      {/* Recommendation Banner */}
      <div className="bg-indigo-600/20 p-6 rounded-[2rem] border border-indigo-500/20 flex items-center justify-between gap-4">
        <div className="flex-1">
          <h4 className="font-bold text-white">Need a custom plan?</h4>
          <p className="text-xs text-indigo-200 mt-1 leading-snug">Let our AI build a 15-min core session based on your goals.</p>
        </div>
        <button className="bg-indigo-500 p-3 rounded-2xl text-white">
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
};

export default Library;
