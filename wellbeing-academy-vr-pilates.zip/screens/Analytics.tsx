
import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, ResponsiveContainer, Tooltip, Cell } from 'recharts';
import { Bell, RefreshCw, Trophy, Target, TrendingUp, Lightbulb } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
// Added Badge import from UI components
import { Badge } from '../components/UI';

const FREQUENCY_DATA = [
  { day: 'M', sessions: 1 },
  { day: 'T', sessions: 2 },
  { day: 'W', sessions: 1 },
  { day: 'T', sessions: 0 },
  { day: 'F', sessions: 3 },
  { day: 'S', sessions: 4 },
  { day: 'S', sessions: 2 },
];

const Analytics: React.FC = () => {
  const [insight, setInsight] = useState<string>("Loading your personalized wellness breakdown...");
  const [loadingInsight, setLoadingInsight] = useState(false);

  useEffect(() => {
    const fetchAIInsight = async () => {
      if (!process.env.API_KEY) return;
      setLoadingInsight(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: "Based on a Pilates student completing 13 sessions this month with 92% form accuracy and peak engagement on weekends, generate a 'Professional Coach Note' (max 20 words). Focus on trust and core progress.",
        });
        if (response.text) {
          setInsight(response.text.trim());
        }
      } catch (e) {
        console.error("AI Insight error:", e);
      } finally {
        setLoadingInsight(false);
      }
    };

    fetchAIInsight();
  }, []);

  return (
    <div className="p-6 space-y-8 pb-32">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Performance</h1>
        <button className="p-2 glass rounded-full">
          <Bell size={20} className="text-slate-400" />
        </button>
      </header>

      {/* Feature 3: Insights - Trust & Differentiation */}
      <section className="relative group">
         <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00C2FF]/30 to-indigo-500/30 rounded-[2.5rem] blur opacity-75"></div>
         <div className="relative glass p-6 rounded-[2.5rem] flex flex-col gap-4 border-[#00C2FF]/20">
            <div className="flex items-center gap-3 text-[#00C2FF]">
               <div className="p-2 bg-[#00C2FF]/10 rounded-xl">
                  <Lightbulb size={24} />
               </div>
               <h3 className="font-bold tracking-tight">AI Coach's Insight</h3>
            </div>
            <p className="text-slate-200 text-sm leading-relaxed italic">
               "{loadingInsight ? "Evaluating metrics..." : insight}"
            </p>
         </div>
      </section>

      {/* Grid Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass p-5 rounded-[2rem] space-y-2 border-white/5">
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Completion</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-bold">94%</span>
            <Target size={14} className="text-green-500 mb-2" />
          </div>
        </div>
        <div className="glass p-5 rounded-[2rem] space-y-2 border-white/5">
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Form Quality</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-bold">A-</span>
            <TrendingUp size={14} className="text-[#00C2FF] mb-2" />
          </div>
        </div>
      </div>

      {/* Engagement Frequency Chart */}
      <section className="glass p-6 rounded-[2.5rem] space-y-6">
        <div className="flex items-center justify-between">
           <div>
              <h3 className="text-lg font-bold">Engagement</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Sessions per Day</p>
           </div>
           <Badge variant="primary">Weekly Peak</Badge>
        </div>
        
        <div className="h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={FREQUENCY_DATA}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
              <Bar dataKey="sessions" radius={[6, 6, 0, 0]}>
                {FREQUENCY_DATA.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.sessions > 2 ? '#00C2FF' : '#1e293b'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Trust & Differentiation Section */}
      <section className="bg-slate-900/50 p-6 rounded-[2rem] border border-white/5 space-y-3">
         <div className="flex items-center gap-2">
            <Trophy size={18} className="text-yellow-500" />
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">Academy Status</h4>
         </div>
         <p className="text-sm font-medium">You are in the top 5% of home-based Pilates practitioners in Bucharest this week.</p>
         <button className="text-xs font-bold text-[#00C2FF] flex items-center gap-1">
            View Regional Leaderboard <TrendingUp size={12} />
         </button>
      </section>
    </div>
  );
};

export default Analytics;
