
import React from 'react';
import { Bell, Sparkles, Smartphone, ChevronRight, Play, CheckCircle } from 'lucide-react';
import { Badge, SessionCard } from '../components/UI';
import { Session, Screen } from '../types';

const MOCK_RECOMMENDED: Session = {
  id: 'rec-1',
  title: 'Core Power Flow',
  instructor: 'Sarah Jenkins',
  duration: 22,
  level: 'Intermediate',
  category: 'Core Focus',
  imageUrl: 'https://images.unsplash.com/photo-1518611012118-296072bb5604?q=80&w=800&auto=format&fit=crop',
  isPopular: true,
};

interface DashboardProps {
  onNavigate: (s: Screen) => void;
  onStartSession: (s: Session) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onStartSession }) => {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img 
            src="https://picsum.photos/seed/alex/100" 
            alt="User" 
            className="w-12 h-12 rounded-full border-2 border-[#00C2FF]/30"
          />
          <div>
            <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Welcome back</p>
            <h1 className="text-lg font-bold">Alex Rivera</h1>
          </div>
        </div>
        <button className="p-2 glass rounded-full relative">
          <Bell size={20} className="text-slate-400" />
          <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#00C2FF] rounded-full border-2 border-[#0A1218] accent-glow" />
        </button>
      </header>

      {/* VR Launch Button - FEATURE 1 ENTRY */}
      <section className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-[#00C2FF] to-indigo-500 rounded-[2.2rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
        <button 
          onClick={() => onStartSession(MOCK_RECOMMENDED)}
          className="relative w-full h-24 bg-slate-900 rounded-[2rem] flex flex-col items-center justify-center border border-white/10 group-hover:border-[#00C2FF]/50 transition-all overflow-hidden"
        >
          <div className="flex items-center gap-3 text-white font-black text-xl tracking-tight z-10">
            <Smartphone size={24} className="text-[#00C2FF]" />
            CONTINUE VR SESSION
          </div>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1 z-10">Sync Headset to Resume</p>
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Play size={80} fill="currentColor" />
          </div>
        </button>
      </section>

      {/* Adaptive Learning Path - FEATURE 2 */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xl font-bold">Your Progress</h2>
          <Badge variant="secondary">Intermediate Path</Badge>
        </div>
        
        <div className="glass p-5 rounded-[2rem] space-y-5">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle size={16} className="text-[#00C2FF]" />
              <span className="font-medium">Foundations</span>
            </div>
            <span className="text-slate-500 font-mono">100%</span>
          </div>
          
          <div className="relative h-1.5 bg-slate-800 rounded-full overflow-hidden">
             <div className="absolute left-0 h-full w-[65%] bg-[#00C2FF] accent-glow rounded-full" />
          </div>

          <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
             <div className="bg-[#00C2FF]/20 p-2 rounded-xl text-[#00C2FF]">
                <Sparkles size={20} />
             </div>
             <div className="flex-1">
                <p className="text-[10px] text-slate-400 font-bold uppercase">Next Milestone</p>
                <p className="text-sm font-bold">Advanced Core Stability</p>
             </div>
             <button onClick={() => onNavigate(Screen.LIBRARY)} className="p-2 text-slate-500 hover:text-white transition-colors">
                <ChevronRight size={20} />
             </button>
          </div>
        </div>
      </section>

      {/* Recommendations */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xl font-bold">Recommended for Today</h2>
        </div>
        <div className="pb-4">
          <SessionCard session={MOCK_RECOMMENDED} orientation="horizontal" />
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
