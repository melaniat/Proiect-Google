
import React, { useState, useEffect } from 'react';
import { X, Mic, Heart, Clock, Activity, AlertCircle } from 'lucide-react';
import { Session } from '../types';
// Added Badge import from UI components
import { Badge } from '../components/UI';

interface SessionPlayerProps {
  session: Session;
  onClose: () => void;
}

const SessionPlayer: React.FC<SessionPlayerProps> = ({ session, onClose }) => {
  const [timeLeft, setTimeLeft] = useState(session.duration * 60);
  const [heartRate, setHeartRate] = useState(72);
  const [cue, setCue] = useState("Preparing environment...");
  const [activePose, setActivePose] = useState("Resting");

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => Math.max(0, prev - 1));
      setHeartRate(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 1000);

    const cues = [
      { t: 5, msg: "Focus on your breath.", pose: "Stretching" },
      { t: 15, msg: "Engage your core now.", pose: "Plank" },
      { t: 30, msg: "Keep shoulders down.", pose: "Plank" },
      { t: 45, msg: "Excellent alignment!", pose: "Transition" },
    ];

    const cueInterval = setInterval(() => {
      const currentSec = session.duration * 60 - timeLeft;
      const activeCue = cues.find(c => c.t === currentSec);
      if (activeCue) {
        setCue(activeCue.msg);
        setActivePose(activeCue.pose);
      }
    }, 1000);

    return () => {
      clearInterval(timer);
      clearInterval(cueInterval);
    };
  }, [timeLeft, session.duration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-500">
      {/* VR Background Simulation */}
      <div className="absolute inset-0 z-0">
        <img 
          src={session.imageUrl} 
          className="w-full h-full object-cover opacity-40 blur-sm scale-110" 
          alt="Background" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/80" />
      </div>

      {/* Top HUD */}
      <header className="relative z-10 flex items-center justify-between p-8">
        <button onClick={onClose} className="p-3 glass rounded-full text-white/70 hover:text-white">
          <X size={24} />
        </button>
        <div className="flex flex-col items-center">
          <p className="text-[10px] text-white/50 font-bold uppercase tracking-[0.3em]">Session In Progress</p>
          <h2 className="text-xl font-bold tracking-tight">{session.title}</h2>
        </div>
        <div className="w-12 h-12 glass rounded-full flex items-center justify-center text-[#00C2FF] animate-pulse">
          <Mic size={20} />
        </div>
      </header>

      {/* Main Experience Area */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-8 text-center gap-12">
        <div className="relative">
          <div className="w-48 h-48 rounded-full border-4 border-white/5 flex items-center justify-center">
             <div className="text-5xl font-light tracking-tighter tabular-nums">{formatTime(timeLeft)}</div>
          </div>
          <svg className="absolute inset-0 w-48 h-48 transform -rotate-90">
            <circle 
              cx="96" cy="96" r="92" 
              stroke="#00C2FF" strokeWidth="4" fill="none" 
              strokeDasharray="578" 
              strokeDashoffset={578 * (1 - timeLeft / (session.duration * 60))}
              strokeLinecap="round"
              className="transition-all duration-1000 accent-glow"
            />
          </svg>
        </div>

        <div className="space-y-4">
           <div className="glass px-6 py-4 rounded-[2rem] border-[#00C2FF]/30 accent-glow bg-[#00C2FF]/10">
              <p className="text-lg font-medium text-white animate-pulse">{cue}</p>
           </div>
           <div className="flex items-center justify-center gap-3">
              <Badge variant="secondary">{activePose}</Badge>
              <div className="flex items-center gap-1 text-green-400 text-xs font-bold">
                 <AlertCircle size={14} /> AI Form Correction: ON
              </div>
           </div>
        </div>
      </main>

      {/* Bottom Telemetry */}
      <footer className="relative z-10 grid grid-cols-3 gap-1 p-8 bg-black/40 backdrop-blur-xl border-t border-white/10">
        <div className="flex flex-col items-center gap-1">
          <Heart size={20} className="text-red-500 animate-bounce" />
          <span className="text-xl font-bold">{heartRate}</span>
          <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider">BPM</span>
        </div>
        <div className="flex flex-col items-center gap-1 border-x border-white/10">
          <Activity size={20} className="text-indigo-400" />
          <span className="text-xl font-bold">428</span>
          <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider">Kcal</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <Clock size={20} className="text-[#00C2FF]" />
          <span className="text-xl font-bold">12:45</span>
          <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider">Remaining</span>
        </div>
      </footer>
    </div>
  );
};

export default SessionPlayer;
